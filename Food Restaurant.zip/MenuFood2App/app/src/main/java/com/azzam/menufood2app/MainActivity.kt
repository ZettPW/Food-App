package com.azzam.menufood2app

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.WindowManager
import androidx.cardview.widget.CardView

class MainActivity : AppCompatActivity() {

    private lateinit var menuayambakar: CardView
    private lateinit var menubakso: CardView
    private lateinit var menusopiga: CardView
    private lateinit var menusotoayam: CardView
    private lateinit var menusotokudus: CardView

    override fun onCreate(savedInstanceState: Bundle?) {
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        menuayambakar = findViewById(R.id.cardView1)
        menubakso = findViewById(R.id.cardView2)
        menusopiga = findViewById(R.id.cardView3)
        menusotoayam = findViewById(R.id.cardView4)
        menusotokudus = findViewById(R.id.cardView5)

        menuayambakar.setOnClickListener {
            val intent = Intent(this, AyamBakar::class.java)
            startActivity(intent)
        }

        menubakso.setOnClickListener {
            val intent = Intent(this, Bakso::class.java)
            startActivity(intent)
        }

        menusopiga.setOnClickListener {
            val intent = Intent(this, SopIga::class.java)
            startActivity(intent)
        }

        menusotoayam.setOnClickListener {
            val intent = Intent(this, SotoAyam::class.java)
            startActivity(intent)
        }

        menusotokudus.setOnClickListener {
            val intent = Intent(this, SotoKudus::class.java)
            startActivity(intent)
        }
    }
}